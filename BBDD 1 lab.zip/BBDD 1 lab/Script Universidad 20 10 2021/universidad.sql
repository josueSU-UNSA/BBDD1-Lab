SHOW DATABASES;
DROP database tablename;
CREATE DATABASE universidad;
USE universidad;
SHOW TABLES;
CREATE TABLE departamento(
depa_id INTEGER PRIMARY KEY,
nombre VARCHAR(30),
edificio INTEGER,
presupuesto DECIMAL(12,2)
);
DESCRIBE departamento;
CREATE TABLE profesor(
prof_id INTEGER ,
nombres VARCHAR(30),
prim_apel VARCHAR(30),
segun_apel VARCHAR(30),
fecha_naci DATE,
depa_id INTEGER ,
primary key(prof_id),
foreign key(depa_id)references departamento(depa_id)
);
describe profesor;
CREATE TABLE estudiante(
estu_id INTEGER ,
nombres VARCHAR(30),
prim_apel VARCHAR(30),
segun_apel VARCHAR(30),
depa_id INTEGER ,
prof_id INTEGER,
primary key(estu_id),
foreign key(depa_id)references departamento(depa_id),
foreign key(prof_id)references profesor(prof_id)
);
describe estudiante;
CREATE TABLE estudiante_telefono(
estu_id INTEGER ,
telefono INTEGER ,
primary key(telefono),
foreign key(estu_id)references estudiante(estu_id)
);
describe estudiante_telefono;
CREATE TABLE curso(
curso_id INTEGER ,
nombre VARCHAR(30),
creditos INTEGER,
depa_id INTEGER ,
primary key(curso_id),
foreign key(depa_id)references departamento(depa_id)
);
describe curso;
DROP TABLE seccion;

CREATE TABLE seccion(
secc_id INTEGER ,
curso_id INTEGER ,
anho INTEGER ,
semestre INTEGER,
foreign key(curso_id)references curso(curso_id),
primary key(secc_id,curso_id)
);
describe seccion;
DROP TABLE estudiante_seccion;
CREATE TABLE estudiante_seccion(
estu_id INTEGER ,
secc_id INTEGER ,
curso_id INTEGER ,
nota INTEGER ,
foreign key(estu_id)references estudiante(estu_id),
foreign key(secc_id)references seccion(secc_id),
foreign key(curso_id)references seccion(curso_id),
primary key(estu_id,secc_id,curso_id )
);
describe estudiante_seccion;
DROP TABLE profesor_seccion;
CREATE TABLE profesor_seccion(
prof_id INTEGER ,
secc_id INTEGER ,
curso_id INTEGER ,
foreign key(prof_id)references profesor(prof_id),
foreign key(secc_id)references seccion(secc_id),
foreign key(curso_id)references seccion(curso_id),
primary key(prof_id,secc_id,curso_id )

);
describe profesor_seccion;

CREATE TABLE pre_requ(
curso_id_1 INTEGER ,
curso_id_2 INTEGER ,
foreign key(curso_id_1)references curso(curso_id),
foreign key(curso_id_2 )references curso(curso_id),
primary key(curso_id_1,curso_id_2)
);
describe pre_requ;
/*
Insercion de datos
*/
/*use universidad*/
show TABLES ;
SELECT * FROM profesor;
/*
Insercion profesor
*/
INSERT INTO cliente
values(1,1000,200,556.78);
/*Muestre todos los profesores que han dictado el curso de Base de Datos I en el año 2019.*/
SHOW TABLES;/*Muestre los cursos con sus pre-requisitos (lo cursos que tienen pre-requisito).*/

/*Muestre los cursos, año y semestre donde el alumno con codigo 987654321 se ha matriculado.*/
/*
Muestre la cantidad de profesorres por departamento
*/
/*SELECT COUNT(prof_id)*/
DESCRIBE profesor;
DESCRIBE profesor_seccion;
DESCRIBE curso;
SELECT d.nombre 'Departamento 1',COUNT(p.prof_id)'Numero de profesores'
FROM departamento d


